# 07 Enterprise License And Pricing

**Project:** TWENTY
**Upstream:** https://github.com/twentyhq/twenty

Content specific to TWENTY in category CONSULTANCY.
