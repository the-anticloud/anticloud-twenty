# 25 Millennium Problem Proposals

**Project:** TWENTY
**Upstream:** https://github.com/twentyhq/twenty

Content specific to TWENTY in category CONSULTANCY.
