# 29 Investor Memo

**Project:** TWENTY
**Upstream:** https://github.com/twentyhq/twenty

Content specific to TWENTY in category CONSULTANCY.
